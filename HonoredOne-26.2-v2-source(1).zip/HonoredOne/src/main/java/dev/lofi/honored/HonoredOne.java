package dev.lofi.honored;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.*;

public final class HonoredOne extends JavaPlugin implements Listener, TabExecutor {

    // ---- tweak these ----
    private static final int SWIRL_TICKS = 16;   // time for the spiral to form once you stop
    private static final int RING_TICKS  = 16;   // time for the ring to draw after the spiral
    private static final double SWIRL_R  = 1.7;  // spiral radius
    private static final double RING_R   = 1.95; // ring radius
    private static final double BEHIND   = 0.9;  // how far behind the player the disc sits
    private static final double CENTER_Y = 1.0;  // height of disc center
    private static final double MOVE_EPS = 0.04; // movement that counts as "moving"

    private static final Particle.DustOptions WHITE = new Particle.DustOptions(Color.fromRGB(240, 246, 255), 0.8f);
    private static final Particle.DustOptions WHITE_SMALL = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 0.6f);

    private static final class State {
        Location last;
        int still = 0; // ticks stationary
    }

    private final Map<UUID, State> marked = new HashMap<>();
    private final Random rng = new Random();
    private long tick = 0;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String s : getConfig().getStringList("marked")) {
            try { marked.put(UUID.fromString(s), new State()); } catch (IllegalArgumentException ignored) {}
        }
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("honored");
        if (cmd != null) { cmd.setExecutor(this); cmd.setTabCompleter(this); }
        Bukkit.getScheduler().runTaskTimer(this, this::renderAll, 20L, 2L);
    }

    @Override
    public void onDisable() { save(); }

    private void save() {
        List<String> out = new ArrayList<>();
        marked.keySet().forEach(u -> out.add(u.toString()));
        getConfig().set("marked", out);
        saveConfig();
    }

    // ---------- effect ----------

    private void renderAll() {
        tick += 2;
        for (Map.Entry<UUID, State> e : marked.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null || !p.isOnline() || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;
            update(p, e.getValue());
        }
    }

    private void update(Player p, State st) {
        Location now = p.getLocation();
        boolean moved = st.last == null
                || !st.last.getWorld().equals(now.getWorld())
                || st.last.distanceSquared(now) > MOVE_EPS * MOVE_EPS;

        if (moved) {
            // break apart if we had formed anything
            if (st.still > 4) dissolve(p, st);
            st.still = 0;
            st.last = now.clone();
            return;
        }

        st.still += 2;
        draw(p, st.still, false);
    }

    /** Plane origin + axes. Disc stands upright behind the player. */
    private Location center(Player p) {
        Vector f = p.getLocation().getDirection().setY(0);
        if (f.lengthSquared() < 1e-6) f = new Vector(0, 0, 1);
        f.normalize();
        return p.getLocation().add(0, CENTER_Y, 0).subtract(f.multiply(BEHIND));
    }

    private Vector[] axes(Player p) {
        Vector f = p.getLocation().getDirection().setY(0);
        if (f.lengthSquared() < 1e-6) f = new Vector(0, 0, 1);
        f.normalize();
        Vector right = new Vector(-f.getZ(), 0, f.getX());
        return new Vector[]{right, new Vector(0, 1, 0)};
    }

    private Location at(Location c, Vector[] ax, double x, double y) {
        return c.clone().add(ax[0].clone().multiply(x)).add(ax[1].clone().multiply(y));
    }

    /**
     * Stage 1: spiral grows outward from the center.
     * Stage 2: ring draws itself around it.
     * Stage 3: both hold, spiral keeps turning.
     * If dissolve==true, particles are scattered instead of drawn clean.
     */
    private void draw(Player p, int still, boolean dissolve) {
        World w = p.getWorld();
        Location c = center(p);
        Vector[] ax = axes(p);

        double sp = Math.min(1.0, still / (double) SWIRL_TICKS);
        double rp = Math.max(0.0, Math.min(1.0, (still - SWIRL_TICKS) / (double) RING_TICKS));
        double spin = tick * 0.06;

        // Spiral: 2 arms, ~1.5 turns
        int arms = 2;
        int perArm = 36;
        double turns = 1.5 * Math.PI * 2;
        for (int a = 0; a < arms; a++) {
            double armOff = a * Math.PI;
            int upTo = (int) (perArm * sp);
            for (int i = 1; i <= upTo; i++) {
                double f = i / (double) perArm;          // 0..1 along the arm
                double ang = f * turns + armOff + spin;
                double r = f * SWIRL_R;
                emit(w, at(c, ax, Math.cos(ang) * r, Math.sin(ang) * r), WHITE, dissolve);
            }
        }

        // Ring: arc grows around the circle
        int ringPts = 56;
        int ringUpTo = (int) (ringPts * rp);
        for (int i = 0; i < ringUpTo; i++) {
            double ang = (Math.PI * 2 / ringPts) * i + spin * 0.4;
            emit(w, at(c, ax, Math.cos(ang) * RING_R, Math.sin(ang) * RING_R), WHITE_SMALL, dissolve);
        }
    }

    private void emit(World w, Location l, Particle.DustOptions o, boolean dissolve) {
        if (dissolve) {
            // scatter outward and drift
            w.spawnParticle(Particle.DUST, l, 1, 0.35, 0.35, 0.35, 0, o, true);
            if (rng.nextInt(6) == 0) w.spawnParticle(Particle.END_ROD, l, 1, 0.1, 0.1, 0.1, 0.04, null, true);
        } else {
            w.spawnParticle(Particle.DUST, l, 1, 0, 0, 0, 0, o, true);
        }
    }

    /** Fires once when the player starts moving: whatever was formed bursts apart. */
    private void dissolve(Player p, State st) {
        for (int i = 0; i < 2; i++) draw(p, st.still, true);
    }

    // ---------- death ----------

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!marked.containsKey(e.getPlayer().getUniqueId())) return;
        Bukkit.broadcast(Component.text("The Honored One Has Perished", NamedTextColor.RED, TextDecoration.BOLD));
    }

    // ---------- command ----------

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length != 1) {
            s.sendMessage(Component.text("Usage: /honored <player|clear|list>", NamedTextColor.GRAY));
            return true;
        }
        if (a[0].equalsIgnoreCase("clear")) {
            marked.clear(); save();
            s.sendMessage(Component.text("Cleared all Honored Ones.", NamedTextColor.GRAY));
            return true;
        }
        if (a[0].equalsIgnoreCase("list")) {
            List<String> names = new ArrayList<>();
            for (UUID u : marked.keySet()) {
                String n = Bukkit.getOfflinePlayer(u).getName();
                names.add(n == null ? u.toString() : n);
            }
            s.sendMessage(Component.text("Honored: " + (names.isEmpty() ? "none" : String.join(", ", names)), NamedTextColor.AQUA));
            return true;
        }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null) {
            s.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
            return true;
        }
        if (marked.remove(t.getUniqueId()) != null) {
            s.sendMessage(Component.text(t.getName() + " is no longer the Honored One.", NamedTextColor.GRAY));
        } else {
            marked.put(t.getUniqueId(), new State());
            s.sendMessage(Component.text(t.getName() + " is now the Honored One.", NamedTextColor.AQUA));
        }
        save();
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (a.length != 1) return List.of();
        List<String> out = new ArrayList<>(List.of("clear", "list"));
        Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        String pre = a[0].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(pre));
        return out;
    }
}
